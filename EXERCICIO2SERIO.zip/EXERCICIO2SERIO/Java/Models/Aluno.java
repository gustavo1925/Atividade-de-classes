package Java.Models;



public class Aluno extends Pessoa {

    private int matricula;
    private Curso curso;

    public Aluno(String nome, String cpf, String email, String telefone, String endereco, int matricula, Curso curso) {
        super(nome, cpf, email, telefone, endereco);

        this.matricula = matricula;
        this.curso = curso;
    }

    // metodos Getter e Setter

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }

    // operaçoes

    public void matricularCurso() {
        System.out.println("Matriculando");
    }

    public void cancelarMatricula() {
        System.out.println("Cancelando");
    }

    @Override
    public void exibirDados() {
        super.exibirDados();
        System.out.println("Matricula:" + this.matricula);
        if (this.curso != null) {
            System.out.println("Curso:" + this.curso.getNome());
        }
    }
}
