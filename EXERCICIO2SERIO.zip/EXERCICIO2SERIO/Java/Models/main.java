package Java.Models;



public class main {
    public static void main(String[] args) {

        Pessoa gustavo = new Pessoa(
        "Gustavo",
        "529.982.247-25",
        "gustavo@gmail.com",
        "(19) 99847-3621",
        "Rua das Acácias, 742");

        Curso cursoGuitarra = new Curso(202, "Guitarra Eletrica", 50);

        Aluno lucas = new Aluno(
        "Lucas", 
        "526.432.234-25", 
        "lucas@hotmail.com", 
        "(19) 99324-2342", 
        "Avenida dos Ipês, 128", 
        1000, 
        cursoGuitarra);

        Professor josue = new Professor(
        "Josue", 
        "123.423.543-25", 
        "josue@outlook.com", 
        "(19) 89329-4329", 
        "Rua João de Barros, 356", 
        90.00, 
        "Flauta");

        
        // Testando

        System.out.println("Dados da Pessoa ---");
        gustavo.exibirDados();

        System.out.println("Cursos Presentes:");
        cursoGuitarra.exibirCurso();

        System.out.println("Dados do Aluno ---");
        lucas.exibirDados();
        lucas.matricularCurso();

        System.out.println("Dados do Professor ---");
        josue.exibirDados();
        josue.ministrarAula();
    }
}

