package Java.Models;



public class Professor extends Pessoa {

    
    private Double salario;
    private String especialidade;
    

    public Professor(String nome, String cpf, String email, String telefone, String endereco, Double salario, String especialidade){
        super(nome, cpf, email, telefone, endereco);

        this.especialidade = especialidade;
        this.salario = salario;
    }

    //metodos Getter e Setter

    public Double getSalario(){
        return salario;
    }

    public void setSalario(Double salario){
        this.salario = salario;
    }

    public String getEspecialidade(){
        return especialidade;
    }

    public void setEspecialidade(String especialidade){
        this.especialidade = especialidade;
    }

    // operaçoes

    public void ministrarAula(){
        System.out.println("Ministrando");
    }
    public void atualizarEspecialidade(){
        System.out.println("Atualizando");
    }

    @Override
    public void exibirDados(){
        super.exibirDados();
        System.out.println("Especialidade:" + this.especialidade);
        System.out.println("Salario:" + this.salario);
    }
}