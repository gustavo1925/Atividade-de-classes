package Java.Models;



public class Curso {
    
    private int codigo;
    private String nome;
    private int cargaHoraria;
    

    public Curso(int codigo, String nome, int cargaHoraria){
        this.codigo = codigo;
        this.nome = nome;
        this.cargaHoraria = cargaHoraria;
    }

    //metodos Getter e Setter

    public int getCodigo(){
        return codigo;
    }

    public void setCodigo(int codigo){
        this.codigo = codigo;
    }

    public String getNome(){
        return nome;
    }

    public void setNome(String nome){
        this.nome = nome;
    }

    public int getCargaHoraria(){
        return cargaHoraria;
    }

    public void setCargaHoraria(int cargaHoraria){
        this.cargaHoraria = cargaHoraria;
    }

    // operaçoes

    public void cadastrarCurso(){
        System.out.println("Cadastrando");
    }
    public void alterarCurso(){
        System.out.println("Alterando");
    }
    public void exibirCurso(){
        System.out.println("Codigo:" + this.codigo);
        System.out.println("Nome do Curso:" + this.nome);
        System.out.println("Carga horaria:" + this.cargaHoraria);
    }
}
