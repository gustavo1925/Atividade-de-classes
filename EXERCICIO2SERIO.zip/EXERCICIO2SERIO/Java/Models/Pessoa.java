package Java.Models;



public class Pessoa {

    private String nome;
    private String cpf;
    private String email;
    private String telefone;
    private String endereco;

    public Pessoa(
        String nome, 
        String cpf, 
        String email, 
        String telefone, 
    String endereco) {

            this.nome = nome;
            this.cpf = cpf;
            this.email = email;
            this.telefone = telefone;
            this.endereco = endereco;
    }

    // metodos Getter e Setter
    public String getNome(){
        return nome;
    }

    public void setNome(String nome){
        this.nome = nome;
    }

    public String getCpf(){
        return cpf;
    }

    public void setCpf(String cpf){
        this.cpf = cpf;
    }
    public String getEmail(){
        return email;
    }

    public void setEmail(String email){
        this.email = email;
    }
    public String getTelefone(){
        return telefone;
    }

    public void setTelefone(String telefone){
        this.telefone = telefone;
    }
    public String getEndereco(){
        return endereco;
    }

    public void setEndereco(String endereco){
        this.endereco = endereco;
    }

    // Operaçoes

    public void cadastrar(){
        System.out.println("Cadastrando");
    }
    public void atualizarDados(){
        System.out.println("Atualizando");
    }
    public void exibirDados(){
        System.out.println("Exibindo:");
        System.out.println("Nome:" + this.nome);
        System.out.println("CPF:" + this.cpf);
        System.out.println("Email:" + this.email);
        System.out.println("Telefone:" + this.telefone);
        System.out.println("Endereço:" + this.endereco);
    }
}
